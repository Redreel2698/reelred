Reddit Reel Bot - Free, Automated, and Offline

1. Replace YOUR_CLIENT_ID and YOUR_CLIENT_SECRET in the script.
2. Place a 9:16 vertical MP4 named "background.mp4" in this folder.
3. Run run_bot.bat (double-click).
4. The final video will be saved as final.mp4.