import os
import re
import requests
import praw
import textwrap
from gtts import gTTS
from moviepy.editor import *
import moviepy.config as mpconf

# --- ImageMagick Setup ---
mpconf.change_settings({
    "IMAGEMAGICK_BINARY": "/usr/bin/convert"
})

# --- Pexels API Key ---
PEXELS_API_KEY = "3JLpwbqUMgq8EngmXQNbHOmhWGWLQLmL9rvLqGoTRk8QKRL1G5FY5HW6"

# --- Reddit API Setup ---
reddit = praw.Reddit(
    client_id='x5nQNYyMH7AfM-ti-VpavA',
    client_secret='Ivo6X_sT6eUmsDYieHgs9T5dTeGRig',
    user_agent='reelbot by /u/RedReelBot'
)

# --- Subreddits ---
SUBREDDITS = ["AskReddit", "TIFU", "confessions"]
USED_POSTS_FILE = "used_post_ids.txt"

# --- Used post tracking ---
def load_used_ids():
    if os.path.exists(USED_POSTS_FILE):
        with open(USED_POSTS_FILE, "r") as f:
            return set(f.read().splitlines())
    return set()

def save_used_id(post_id):
    with open(USED_POSTS_FILE, "a") as f:
        f.write(post_id + "\n")

# --- Fetch Reddit post ---
def get_post():
    print("[*] Fetching posts from subreddits:", SUBREDDITS)
    used_ids = load_used_ids()

    for subreddit_name in SUBREDDITS:
        for post in reddit.subreddit(subreddit_name).top("day", limit=10):
            if post.stickied or post.over_18 or post.id in used_ids:
                continue
            print(f"--> Title: {post.title}")
            print(f"    [✅ selected from r/{subreddit_name}]")
            save_used_id(post.id)
            return post.title, post.selftext

    print("[!] Skipped: No valid Reddit post found.")
    return None, None

# --- Download background video from Pexels ---
def download_background_video(query):
    print(f"[*] Searching Pexels for background using keyword: {query}")
    headers = {"Authorization": PEXELS_API_KEY}
    fallback = "nature"
    attempts = 0
    max_attempts = 2

    while attempts < max_attempts:
        search_term = query if attempts == 0 else fallback
        response = requests.get(
            "https://api.pexels.com/videos/search",
            headers=headers,
            params={"query": search_term, "per_page": 1, "orientation": "portrait"}
        )
        data = response.json()
        if data.get("videos"):
            video = data["videos"][0]
            mp4_links = [f for f in video["video_files"] if f["file_type"] == "video/mp4"]
            if not mp4_links:
                print("[!] No MP4 video found. Trying fallback...")
                attempts += 1
                continue
            best_file = sorted(mp4_links, key=lambda x: x["height"], reverse=True)[0]
            url = best_file["link"]
            print(f"[→] Downloading background from: {url}")
            video_data = requests.get(url).content
            with open("background.mp4", "wb") as f:
                f.write(video_data)
            print(f"[✓] Background downloaded from Pexels using keyword: {search_term}")
            return
        else:
            print(f"[!] No video found for '{search_term}'. Retrying with fallback...")
            attempts += 1

    print("[!] Failed to get background. Will use solid black.")

# --- Make the video ---
def make_video(title, body):
    print("[*] Generating audio...")
    tts = gTTS(text=title + ". " + body, lang='en')
    tts.save("audio.mp3")
    audio = AudioFileClip("audio.mp3")

    print("[*] Generating text image...")
    full_text = (title + "\n\n" + body)[:800]  # <-- Add this
    wrapped = textwrap.fill(full_text, width=40)
    txt_clip = TextClip(
    	wrapped,
    	fontsize=48,
    	color='white',
    	size=(720, 1280),
    	method='caption',
    	align='center',
    	transparent=True,
    	font='DejaVu-Sans'
    ).set_duration(audio.duration).set_position("center")

    if os.path.exists("background.mp4"):
        print("[✓] Using background.mp4")
        bg = VideoFileClip("background.mp4").resize((720, 1280)).loop(duration=audio.duration)
    else:
        print("[!] No background found, using black screen.")
        bg = ColorClip((720, 1280), color=(0, 0, 0), duration=audio.duration)

    final = CompositeVideoClip([bg, txt_clip]).set_audio(audio)
    print("[*] Rendering final.mp4...")
    final.write_videofile("final.mp4", fps=24)
    print("[✓] Video created: final.mp4")

# --- Title cleaner ---
def clean_title(text):
    text = re.sub(r'[^\w\s\-.,!?]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text[:95]

# --- Hashtag/tag generator ---
def generate_tags(title, body):
    base_tags = ["reddit", "shorts", "fyp", "viral"]
    keywords = [word.strip("#.,!?").lower() for word in title.split() if len(word) > 4]
    top_keywords = sorted(set(keywords), key=keywords.count, reverse=True)[:5]
    return base_tags + top_keywords

def generate_hashtag_description(title, body):
    tags = generate_tags(title, body)
    hashtags = " ".join(f"#{tag}" for tag in tags)
    return f"{body}\n\n{hashtags}"

# --- MAIN ---
title, body = get_post()

if not title or not title.strip():
    print("[!] Empty title from Reddit. Using fallback title.")
    title = "Interesting Reddit Story"

title = clean_title(title)
print(f"[*] Cleaned video title: '{title}'")

if not body:
    body = "A trending post from Reddit."

tts = gTTS(text=title + ". " + body, lang='en')
tts.save("audio.mp3")

download_background_video(title)
make_video(title, body)

from youtube_upload import upload_video

tags = generate_tags(title, body)
description = generate_hashtag_description(title, body)

print(f"[*] Final video title: '{title}'")
print(f"[*] Tags: {tags}")
print(f"[*] Description preview:\n{description[:200]}...")

upload_video(
    file_path="final.mp4",
    title=title,
    description=description,
    tags=tags
)

for f in ["audio.mp3", "background.mp4", "final.mp4"]:
    try:
        os.remove(f)
    except:
        pass

