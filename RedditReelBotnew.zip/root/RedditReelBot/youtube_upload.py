import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# OAuth scope for uploading video to YouTube
SCOPES = ['https://www.googleapis.com/auth/youtube.upload']
CLIENT_SECRETS_FILE = "client_secret.json"  # This should already be in your folder


def get_authenticated_service():
    credentials = None
    if os.path.exists("token.pickle"):
        with open("token.pickle", "rb") as token:
            credentials = pickle.load(token)

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            from google.auth.transport.requests import Request
            credentials.refresh(Request())
            with open("token.pickle", "wb") as token:
                pickle.dump(credentials, token)
        else:
            raise Exception("Missing or invalid credentials. Re-authentication required on a machine with a browser.")

    return build("youtube", "v3", credentials=credentials)

def upload_video(file_path, title, description, tags, privacyStatus="public"):
    youtube = get_authenticated_service()

    request_body = {
        'snippet': {
            'title': title,
            'description': description,
            'tags': tags,
            'categoryId': '22',  # 'People & Blogs'
        },
        'status': {
            'privacyStatus': privacyStatus,
            'madeForKids': False
        }
    }

    media_file = MediaFileUpload(file_path, chunksize=-1, resumable=True)

    print("[*] Uploading to YouTube...")
    upload_request = youtube.videos().insert(
        part="snippet,status",
        body=request_body,
        media_body=media_file
    )

    response = None
    while response is None:
        status, response = upload_request.next_chunk()
        if status:
            print(f"[→] Upload progress: {int(status.progress() * 100)}%")

    print(f"[✓] Video uploaded: https://youtube.com/watch?v={response['id']}")



if __name__ == "__main__":
    print("[*] Starting YouTube upload test...")

    upload_video(
        file_path="final.mp4",
        title="Reddit Story: Judge Blocks Trump from Cutting Off Funding",
        description="Generated using RedditReelBot with AI. #reddit #shorts",
        tags=["Reddit", "AI", "Story", "Shorts", "AskReddit"],
        privacyStatus="public"
    )

